-- MySQL dump 10.13  Distrib 5.7.28, for Linux (x86_64)
--
-- Host: localhost    Database: rainloop
-- ------------------------------------------------------
-- Server version	5.7.28-0ubuntu0.18.04.4

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `rainloop`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `rainloop` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `rainloop`;

--
-- Table structure for table `rainloop_ab_contacts`
--

DROP TABLE IF EXISTS `rainloop_ab_contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rainloop_ab_contacts` (
  `id_contact` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_contact_str` varchar(128) NOT NULL DEFAULT '',
  `id_user` int(10) unsigned NOT NULL,
  `display` varchar(255) NOT NULL DEFAULT '',
  `changed` int(10) unsigned NOT NULL DEFAULT '0',
  `deleted` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `etag` varchar(128) CHARACTER SET ascii NOT NULL DEFAULT '',
  PRIMARY KEY (`id_contact`),
  KEY `id_user_rainloop_ab_contacts_index` (`id_user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rainloop_ab_contacts`
--

LOCK TABLES `rainloop_ab_contacts` WRITE;
/*!40000 ALTER TABLE `rainloop_ab_contacts` DISABLE KEYS */;
/*!40000 ALTER TABLE `rainloop_ab_contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rainloop_ab_properties`
--

DROP TABLE IF EXISTS `rainloop_ab_properties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rainloop_ab_properties` (
  `id_prop` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_contact` bigint(20) unsigned NOT NULL,
  `id_user` int(10) unsigned NOT NULL,
  `prop_type` tinyint(3) unsigned NOT NULL,
  `prop_type_str` varchar(255) CHARACTER SET ascii NOT NULL DEFAULT '',
  `prop_value` text NOT NULL,
  `prop_value_custom` text NOT NULL,
  `prop_value_lower` text NOT NULL,
  `prop_frec` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_prop`),
  KEY `id_user_rainloop_ab_properties_index` (`id_user`),
  KEY `id_user_id_contact_rainloop_ab_properties_index` (`id_user`,`id_contact`),
  KEY `id_contact_prop_type_rainloop_ab_properties_index` (`id_contact`,`prop_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rainloop_ab_properties`
--

LOCK TABLES `rainloop_ab_properties` WRITE;
/*!40000 ALTER TABLE `rainloop_ab_properties` DISABLE KEYS */;
/*!40000 ALTER TABLE `rainloop_ab_properties` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rainloop_system`
--

DROP TABLE IF EXISTS `rainloop_system`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rainloop_system` (
  `sys_name` varchar(50) NOT NULL,
  `value_int` int(10) unsigned NOT NULL DEFAULT '0',
  `value_str` varchar(128) NOT NULL DEFAULT '',
  KEY `sys_name_rainloop_system_index` (`sys_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rainloop_system`
--

LOCK TABLES `rainloop_system` WRITE;
/*!40000 ALTER TABLE `rainloop_system` DISABLE KEYS */;
INSERT INTO `rainloop_system` VALUES ('mysql-ab-version_version',3,'');
/*!40000 ALTER TABLE `rainloop_system` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rainloop_users`
--

DROP TABLE IF EXISTS `rainloop_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rainloop_users` (
  `id_user` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rl_email` varchar(128) NOT NULL DEFAULT '',
  PRIMARY KEY (`id_user`),
  KEY `rl_email_rainloop_users_index` (`rl_email`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rainloop_users`
--

LOCK TABLES `rainloop_users` WRITE;
/*!40000 ALTER TABLE `rainloop_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `rainloop_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'rainloop'
--

--
-- Dumping routines for database 'rainloop'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-12-22  6:25:01
